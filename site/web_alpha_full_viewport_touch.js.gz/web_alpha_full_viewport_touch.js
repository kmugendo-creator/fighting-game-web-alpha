(function () {
  "use strict";

  const touchTypes = new Set(["touchstart", "touchmove", "touchend", "touchcancel"]);
  const godotTouchListeners = new Map();
  const nativeCanvasAddEventListener = HTMLCanvasElement.prototype.addEventListener;

  // Godot attaches its real browser-touch callbacks directly to #canvas. Keep
  // those callbacks intact, but remember them so real touches which begin in
  // the letterbox area can enter exactly the same engine input path.
  HTMLCanvasElement.prototype.addEventListener = function (type, listener, options) {
    if (this.id === "canvas" && touchTypes.has(type) && listener) {
      let listeners = godotTouchListeners.get(type);
      if (!listeners) {
        listeners = new Set();
        godotTouchListeners.set(type, listeners);
      }
      listeners.add(listener);
      document.documentElement.dataset.fullViewportTouchBridge = "ready";
      document.documentElement.dataset.fullViewportTouchTypes = String(godotTouchListeners.size);
    }
    return nativeCanvasAddEventListener.call(this, type, listener, options);
  };

  const diagnostics = {
    forwardedEvents: 0,
    lastType: "",
    lastClientX: 0,
    lastClientY: 0,
  };
  window.__godotFullViewportTouchBridge = diagnostics;
  document.documentElement.dataset.fullViewportTouchBridge = "loading";

  function forwardOutsideCanvas(event) {
    const canvas = document.getElementById("canvas");
    if (!canvas || event.target === canvas || canvas.contains(event.target)) {
      return;
    }
    const listeners = godotTouchListeners.get(event.type);
    if (!listeners || listeners.size === 0) {
      return;
    }
    const changedTouch = event.changedTouches && event.changedTouches[0];
    diagnostics.forwardedEvents += 1;
    diagnostics.lastType = event.type;
    diagnostics.lastClientX = changedTouch ? changedTouch.clientX : 0;
    diagnostics.lastClientY = changedTouch ? changedTouch.clientY : 0;
    document.documentElement.dataset.fullViewportTouchForwarded = String(diagnostics.forwardedEvents);
    for (const listener of listeners) {
      if (typeof listener === "function") {
        listener.call(canvas, event);
      } else if (listener && typeof listener.handleEvent === "function") {
        listener.handleEvent(event);
      }
    }
  }

  for (const type of touchTypes) {
    document.addEventListener(type, forwardOutsideCanvas, { capture: true, passive: false });
  }
})();
